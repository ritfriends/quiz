<?php

$lang['jb_blankpage_message'] = "Процесс загрузки еще не начался, либо начался и еще не завершился, либо просто нет связи с удаленным сервером.";

/* End of file jbstrings_lang.php */
/* Location: ./application/language/russian/jbstrings_lang.php */
