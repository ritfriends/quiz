<?php 
exit('Access denied!');
?>