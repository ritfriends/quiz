<?php 
		$sq_base_url='';
		$sq_hostname='localhost';
		$sq_dbname='';
		$sq_dbusername='root';
		$sq_dbpassword='';
		?>