 <div class="container">
  
   
 <div class="alert alert-warning"> Payment gateway files not available !<br>Visit <a href="http://savsoftquiz.com/">www.savsoftquiz.com</a> & Buy commercial license to get this functionality. </div>
 


 




</div>