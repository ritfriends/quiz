<html>
<head>
<style>
html,body{
	margin:0px;
	padding:0px;
	font-family: "Helvetica Neue",Helvetica,Arial,sans-serif;
}
</style>
	 
</head>

<body>
<!-- 
<div style="background-image:url('<?php echo base_url('images/certificate_bg.png');?>'); background-repeat: no-repeat; width:752px;height:505px;padding:35px; " > 
-->
<div style="background-image:url('./images/certificate_bg.png'); background-repeat: no-repeat; width:752px;height:505px;padding:35px;">

<?php echo $certificate_text; ?>
</div>
</body>

</html>