 <div class="container">

  <div class="row">
    
<div class="col-md-8">
<br> 
 <div class="login-panel panel panel-default">
		<div class="panel-body"> 
	  	<img src="<?php echo base_url('images/logo.png');?>">
	
 <h3><?php echo $this->lang->line('subscription_expired_message');?></h3>
   
 <br>
 <div class="alert alert-warning"> Payment gateway files not available !<br>Visit <a href="http://savsoftquiz.com/">www.savsoftquiz.com</a> & Buy commercial license to get this functionality. </div>
 
 
 
 
 
 
</div> 

</div> 

</div> 

</div> 
 


</div> 